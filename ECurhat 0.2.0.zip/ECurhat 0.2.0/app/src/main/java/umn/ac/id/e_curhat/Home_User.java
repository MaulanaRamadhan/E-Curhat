package umn.ac.id.e_curhat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.WindowManager;

import com.google.firebase.auth.FirebaseAuth;

public class Home_User extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Remove Action Bar
        getSupportActionBar().hide();
        setContentView(R.layout.activity_home__user);

        FirebaseAuth fAuth = FirebaseAuth.getInstance();
    }
}