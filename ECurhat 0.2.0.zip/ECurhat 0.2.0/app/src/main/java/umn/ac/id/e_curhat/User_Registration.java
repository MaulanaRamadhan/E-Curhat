package umn.ac.id.e_curhat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class User_Registration extends AppCompatActivity {

    EditText mNama, mEmail, mPassword;
    Button mbtnRegister;
    FirebaseAuth fAuth;
    ProgressBar progressbar2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user__registration);

        mNama = findViewById(R.id.editTextName);
        mEmail = findViewById(R.id.editTextEmail);
        mPassword = findViewById(R.id.editTextPassword);
        mbtnRegister = findViewById(R.id.btnRegister);

        fAuth = FirebaseAuth.getInstance();
        progressbar2 = findViewById(R.id.progressbar2);

        if (fAuth.getCurrentUser() != null) {
            startActivity(new Intent(getApplicationContext(), User_Registration.class));
            finish();
        }

        mbtnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = mEmail.getText().toString().trim();
                String password = mPassword.getText().toString().trim();

                if (TextUtils.isEmpty(email)) {
                    mEmail.setError("Kolom Email Wajib Diisi! ");
                    return;
                }
                if (TextUtils.isEmpty(password)) {
                    mPassword.setError("Kolom Password Wajib Diisi! ");
                    return;
                }
                if (password.length() < 6) {
                    mPassword.setError("Password Wajib Minimal 6 Karakter");
                    return;
                }

                progressbar2.setVisibility(View.VISIBLE);

                fAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(User_Registration.this, "berhasil", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        } else {
                            Toast.makeText(User_Registration.this, "Error !" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            progressbar2.setVisibility(View.GONE);
                        }
                    }
                });

            }
        });
    }
}