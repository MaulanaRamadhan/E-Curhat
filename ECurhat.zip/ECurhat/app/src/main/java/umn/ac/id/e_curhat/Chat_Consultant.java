package umn.ac.id.e_curhat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Chat_Consultant extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat__consultant);
    }
}