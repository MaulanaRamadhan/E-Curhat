package umn.ac.id.e_curhat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        TextView createAccount = (TextView)findViewById(R.id.textView3);

        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                openHalaman_createAccount();
            }
        });
    }

    public void openHalaman_createAccount(){
        Intent intent = new Intent(this, Registration.class);
        startActivity(intent);
    }
}