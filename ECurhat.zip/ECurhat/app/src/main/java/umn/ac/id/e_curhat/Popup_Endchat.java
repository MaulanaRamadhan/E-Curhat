package umn.ac.id.e_curhat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Popup_Endchat extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_popup__endchat);
    }
}